# CryptoAir Phishing Page

## Author: [k4itrun](https://github.com/k4itrun)

#### This is created for educational purposes demonstrating how phishing works.

### Use/Copy it legally and provide proper credit