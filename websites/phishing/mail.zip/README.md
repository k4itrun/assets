# Mail Phshing Page

## Author: k4itrun

### License MIT

***Created for educational purposes***


### [~] Find Me on :
- [![Github](https://img.shields.io/badge/Github-k4itrun-green?style=for-the-badge&logo=github)](https://github.com/k4itrun)

- [![Gmail](https://img.shields.io/badge/Gmail-k4itrun-green?style=for-the-badge&logo=gmail)](mailto:k4itrunkrd@gmail.com)
 
- [![Facebook](https://img.shields.io/badge/Facebook-k4itrun-green?style=for-the-badge&logo=messenger)](https://facebook.com/k4itrun)

- [![Messenger](https://img.shields.io/badge/Messenger-k4itrun-green?style=for-the-badge&logo=messenger)](https://m.me/k4itrun)