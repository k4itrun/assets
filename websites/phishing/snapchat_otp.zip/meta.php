<meta content="user-scalable=no,initial-scale=1,maximum-scale=1" name="viewport"/>
<meta content="origin-when-crossorigin" id="meta_referrer" name="referrer"/>
<meta content="#3b5998" name="theme-color"/>
<meta content="AvpndGzuAwLY463N1HvHrsK3WE5yU5g6Fehz7Vl7bomqhPI/nYGOjVg3TI0jq5tQ5dP3kDSd1HXVtKMQyZPRxAAAAABleyJvcmlnaW4iOiJodHRwczovL2ZhY2Vib29rLmNvbTo0NDMiLCJmZWF0dXJlIjoiSW5zdGFsbGVkQXBwIiwiZXhwaXJ5IjoxNTEyNDI3NDA0LCJpc1N1YmRvbWFpbiI6dHJ1ZX0=" data-expires="2017-12-04" data-feature="getInstalledRelatedApps" http-equiv="origin-trial"/>
<meta content="noodp,noydir,noindex,noimageindex" name="robots"/>
<meta content="বয়কট এর বানান হল boycott,  কোনোভাবে boykot নয় :)

আর এই প্রতিষ্ঠানের নাম rumor scanner ( রিউমার স্ক্যানার) ,  কোনোভাবেই এটা rumor scenar ( রিউমার সিনার)..." name="description"/>
<meta content="Jahirul Islam" property="og:title"/>
<meta content="বয়কট এর বানান হল boycott,  কোনোভাবে boykot নয় :)

আর এই প্রতিষ্ঠানের নাম rumor scanner ( রিউমার স্ক্যানার) ,  কোনোভাবেই এটা rumor scenar ( রিউমার সিনার)  নয়

#বানান_আন্দোলন

Rumor Scanner..." property="og:description"/>
<meta content="https://scontent.fdac80-1.fna.fbcdn.net/v/t39.30808-6/289920366_2227412190768451_1147823692424629286_n.jpg?stp=cp0_dst-jpg_e15_fr_q65&amp;_nc_cat=110&amp;ccb=1-7&amp;_nc_sid=110474&amp;_nc_ohc=J5rmRBSyrucAX8MRFQY&amp;_nc_ht=scontent.fdac80-1.fna&amp;oh=00_AT8XGk7UNSOOP2d5S9fGwjpi4mQdN3N9IbkpBOdQqYrnwA&amp;oe=62C7BE21" property="og:image"/>
<meta content="https://www.facebook.com/story.php?story_fbid=pfbid0nzYLPtHswuNg2Ry6ZynFArf4JiMX2avXrkAqMAhmjN711ECjWpLx7vniJWi8EauNl&amp;id=100004990757830" property="og:url"/>
